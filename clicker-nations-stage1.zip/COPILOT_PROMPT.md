Ти працюєш у репозиторії World Clicker (Telegram Mini App; React 18 + Vite, MapLibre, Supabase kv_store, Vercel api/).
Завдання: застосувати етап 1 переробки (див. STAGE1.md), нічого не ламаючи.
Правила: не змінюй public/data/cities.json і інші public/data/*; не додавай файлів у корінь api/ (ліміт 12; нові модулі лише в api/_game/); не послаблюй захист (hardening.sql, перевірка initData); не змінюй схему ключів kv_store; секрети не в клієнт; інтерфейс українською; залежності не видаляй.
Кроки:
1. Накати файли з архіву поверх репозиторію (змінені: api/_game/state.js, src/App.jsx, src/DroneGame.jsx, src/powerApi.js, package.json; нові: api/_game/publicPlayer.js, src/core/*, src/droneModels.js, tests/*).
2. npm install && npm test && npm run build. Якщо збірка падає — виправ мінімально й опиши, що саме; не переписуй логіку.
3. Переконайся, що в dist є окремі чанки DroneGame і SniperGame.
4. Запусти dev, у DevTools Network відкрий вкладки Рейтинг і Карта: має бути один запит action=state з op players-snapshot, а не серія запитів до kv_store.
5. Повідом: вивід build (розміри чанків), результат npm test, що не вдалось перевірити.
Не додавай нових можливостей поза STAGE1.md.

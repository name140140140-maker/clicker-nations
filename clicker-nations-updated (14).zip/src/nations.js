/* Країни гравців і володіння територіями.

   Усе зберігається в тій самій таблиці Supabase `kv_store`, що й решта гри:
     country:<id>   — JSON країни { id, name, color, leaderId, createdAt, regionIds[] }
     terr:<regionId> — id країни, яка володіє областю (запис створюється атомарно,
                       тож одну вільну область не можуть зайняти двоє одночасно)
   Нові таблиці чи міграції в Supabase не потрібні. */

import { loadRegionOwners, buildRealCountries } from "./realCountries";
import { sbStorageGet, sbStorageSet, sbStorageListEntries, sbStorageInsertIfAbsent } from "./supabaseStorage";

export const COUNTRY_PREFIX = "country:";
export const TERRITORY_PREFIX = "terr:";
export const CITY_OWN_PREFIX = "cityown:"; // перехоплені міста: cityown:<cityKey> → id країни
export const CHANGELOG_KEY = "changelog";

/* Обмежена палітра кольорів країн (кожна країна має свій колір; лідер може змінити в Панелі управління). */
export const COUNTRY_COLORS = [
  "#ef4444", "#f97316", "#f59e0b", "#eab308", "#84cc16", "#22c55e",
  "#10b981", "#14b8a6", "#06b6d4", "#3b82f6", "#6366f1", "#8b5cf6",
  "#a855f7", "#d946ef", "#ec4899", "#f43f5e", "#b91c1c", "#c2410c",
  "#a16207", "#4d7c0f", "#15803d", "#0f766e", "#1d4ed8", "#6d28d9",
];

export const NAME_MIN = 2;
export const NAME_MAX = 24;

export const normName = (s) => String(s || "").trim().replace(/\s+/g, " ").toLowerCase();

export function newCountryId() {
  return "c" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/* Завантажує країни й володіння. Країни — реальні (id = ISO), стартове володіння областей
   береться з region-owners.json; з бази накладаємо лише лідерів країн, захоплення областей
   (terr:*) і міст (cityown:*). Записи зі старих вигаданих країн (id не ISO) ігноруються —
   так світ стартує з нуля без видалення чогось у базі. Повертає null, якщо дані недоступні. */
export async function loadNations(lang = "uk") {
  const [ro, cEntries, tEntries, oEntries] = await Promise.all([
    loadRegionOwners(),
    sbStorageListEntries(COUNTRY_PREFIX, true),
    sbStorageListEntries(TERRITORY_PREFIX, true),
    sbStorageListEntries(CITY_OWN_PREFIX, true),
  ]);
  if (!ro || !cEntries || !tEntries) return null;
  const countries = buildRealCountries(ro, lang);
  const byId = new Map(countries.map((c) => [c.id, c]));
  for (const e of cEntries) {
    try {
      const rec = JSON.parse(e.value);
      const c = rec && byId.get(rec.id);
      if (c) { c.leaderId = rec.leaderId || null; c.createdAt = rec.createdAt || 0; }
    } catch {
      /* пошкоджений запис — пропускаємо */
    }
  }
  const owners = { ...ro.r };
  for (const e of tEntries) {
    if (byId.has(e.value)) owners[e.key.slice(TERRITORY_PREFIX.length)] = e.value;
  }
  const counts = {};
  for (const rid in owners) counts[owners[rid]] = (counts[owners[rid]] || 0) + 1;
  for (const c of countries) c.regionCount = counts[c.id] || 0;
  const cityOwners = {};
  for (const e of oEntries || []) if (byId.has(e.value)) cityOwners[e.key.slice(CITY_OWN_PREFIX.length)] = e.value;
  return { countries, owners, cityOwners };
}

export function pickFreeColor(countries) {
  const used = new Set((countries || []).map((c) => c.color));
  const free = COUNTRY_COLORS.filter((c) => !used.has(c));
  const pool = free.length ? free : COUNTRY_COLORS;
  return pool[Math.floor(Math.random() * pool.length)];
}

/* Прибирає керівні й невидимі символи (зокрема RTL-підміну тексту) */
export function sanitizeName(name) {
  return String(name || "")
    .replace(/[\u0000-\u001F\u007F-\u009F\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

export function validateCountryName(name, countries) {
  const n = sanitizeName(name);
  if (n.length < NAME_MIN) return `Назва має містити щонайменше ${NAME_MIN} символи`;
  if (n.length > NAME_MAX) return `Назва не може бути довшою за ${NAME_MAX} символів`;
  const key = normName(n);
  if ((countries || []).some((c) => normName(c.name) === key)) return "Країна з такою назвою вже існує";
  return "";
}

/* Створює країну: атомарно займає вільну область, потім записує країну.
   Повертає { ok:true, country } або { ok:false, reason, taken? } */
export async function createCountry() {
  // Нові країни більше не створюються: світ складається зі справжніх країн, а власність карти веде сервер
  return { ok: false, reason: "Створення власних країн вимкнено. Обери одну з існуючих країн." };
}

/* Лише лідер змінює колір (перевірка на боці інтерфейсу). */
export async function updateCountryColor(countryId, color) {
  if (!COUNTRY_COLORS.includes(color)) return { ok: false, reason: "Недопустимий колір" };
  const raw = await sbStorageGet(COUNTRY_PREFIX + countryId, true);
  if (!raw) return { ok: false, reason: "Країну не знайдено" };
  let c;
  try { c = JSON.parse(raw); } catch { return { ok: false, reason: "Пошкоджені дані країни" }; }
  c.color = color;
  const ok = await sbStorageSet(COUNTRY_PREFIX + countryId, JSON.stringify(c), true);
  return ok ? { ok: true, country: c } : { ok: false, reason: "Не вдалося зберегти" };
}

/* --- Список оновлень (для адмін-панелі) --- */
export async function loadChangelog() {
  const raw = await sbStorageGet(CHANGELOG_KEY, true);
  if (!raw) return [];
  try {
    const list = JSON.parse(raw);
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

export async function saveChangelog(list) {
  return sbStorageSet(CHANGELOG_KEY, JSON.stringify(list), true);
}
